/****************************************************************************
** Meta object code from reading C++ file 'bleconnect.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../bleconnect.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'bleconnect.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_BLEConnect_t {
    QByteArrayData data[34];
    char stringdata0[470];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_BLEConnect_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_BLEConnect_t qt_meta_stringdata_BLEConnect = {
    {
QT_MOC_LITERAL(0, 0, 10), // "BLEConnect"
QT_MOC_LITERAL(1, 11, 7), // "fromBle"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 3), // "msg"
QT_MOC_LITERAL(4, 24, 13), // "receiveBleMsg"
QT_MOC_LITERAL(5, 38, 10), // "sendRquest"
QT_MOC_LITERAL(6, 49, 13), // "returnAddress"
QT_MOC_LITERAL(7, 63, 20), // "QBluetoothDeviceInfo"
QT_MOC_LITERAL(8, 84, 8), // "addItems"
QT_MOC_LITERAL(9, 93, 4), // "item"
QT_MOC_LITERAL(10, 98, 9), // "addDevice"
QT_MOC_LITERAL(11, 108, 6), // "device"
QT_MOC_LITERAL(12, 115, 23), // "on_blue_connect_clicked"
QT_MOC_LITERAL(13, 139, 7), // "address"
QT_MOC_LITERAL(14, 147, 22), // "on_blue_search_clicked"
QT_MOC_LITERAL(15, 170, 7), // "checked"
QT_MOC_LITERAL(16, 178, 12), // "scanFinished"
QT_MOC_LITERAL(17, 191, 9), // "createCtl"
QT_MOC_LITERAL(18, 201, 17), // "serviceDiscovered"
QT_MOC_LITERAL(19, 219, 14), // "QBluetoothUuid"
QT_MOC_LITERAL(20, 234, 4), // "gatt"
QT_MOC_LITERAL(21, 239, 15), // "serviceScanDone"
QT_MOC_LITERAL(22, 255, 19), // "serviceStateChanged"
QT_MOC_LITERAL(23, 275, 31), // "QLowEnergyService::ServiceState"
QT_MOC_LITERAL(24, 307, 1), // "s"
QT_MOC_LITERAL(25, 309, 20), // "searchCharacteristic"
QT_MOC_LITERAL(26, 330, 31), // "BleServiceCharacteristicChanged"
QT_MOC_LITERAL(27, 362, 24), // "QLowEnergyCharacteristic"
QT_MOC_LITERAL(28, 387, 1), // "c"
QT_MOC_LITERAL(29, 389, 5), // "value"
QT_MOC_LITERAL(30, 395, 28), // "BleServiceCharacteristicRead"
QT_MOC_LITERAL(31, 424, 29), // "BleServiceCharacteristicWrite"
QT_MOC_LITERAL(32, 454, 10), // "sendBleMsg"
QT_MOC_LITERAL(33, 465, 4) // "text"

    },
    "BLEConnect\0fromBle\0\0msg\0receiveBleMsg\0"
    "sendRquest\0returnAddress\0QBluetoothDeviceInfo\0"
    "addItems\0item\0addDevice\0device\0"
    "on_blue_connect_clicked\0address\0"
    "on_blue_search_clicked\0checked\0"
    "scanFinished\0createCtl\0serviceDiscovered\0"
    "QBluetoothUuid\0gatt\0serviceScanDone\0"
    "serviceStateChanged\0QLowEnergyService::ServiceState\0"
    "s\0searchCharacteristic\0"
    "BleServiceCharacteristicChanged\0"
    "QLowEnergyCharacteristic\0c\0value\0"
    "BleServiceCharacteristicRead\0"
    "BleServiceCharacteristicWrite\0sendBleMsg\0"
    "text"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_BLEConnect[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  104,    2, 0x06 /* Public */,
       4,    1,  107,    2, 0x06 /* Public */,
       5,    1,  110,    2, 0x06 /* Public */,
       6,    1,  113,    2, 0x06 /* Public */,
       8,    1,  116,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      10,    1,  119,    2, 0x0a /* Public */,
      12,    1,  122,    2, 0x0a /* Public */,
      14,    1,  125,    2, 0x0a /* Public */,
      16,    0,  128,    2, 0x0a /* Public */,
      17,    1,  129,    2, 0x0a /* Public */,
      18,    1,  132,    2, 0x0a /* Public */,
      21,    0,  135,    2, 0x0a /* Public */,
      22,    1,  136,    2, 0x0a /* Public */,
      25,    0,  139,    2, 0x0a /* Public */,
      26,    2,  140,    2, 0x0a /* Public */,
      30,    2,  145,    2, 0x0a /* Public */,
      31,    2,  150,    2, 0x0a /* Public */,
      32,    1,  155,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, 0x80000000 | 7,    2,
    QMetaType::Void, QMetaType::QString,    9,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 7,   11,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 7,    2,
    QMetaType::Void, 0x80000000 | 19,   20,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 23,   24,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 27, QMetaType::QByteArray,   28,   29,
    QMetaType::Void, 0x80000000 | 27, QMetaType::QByteArray,   28,   29,
    QMetaType::Void, 0x80000000 | 27, QMetaType::QByteArray,   28,   29,
    QMetaType::Void, QMetaType::QString,   33,

       0        // eod
};

void BLEConnect::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<BLEConnect *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->fromBle((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->receiveBleMsg((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->sendRquest((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->returnAddress((*reinterpret_cast< QBluetoothDeviceInfo(*)>(_a[1]))); break;
        case 4: _t->addItems((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->addDevice((*reinterpret_cast< const QBluetoothDeviceInfo(*)>(_a[1]))); break;
        case 6: _t->on_blue_connect_clicked((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->on_blue_search_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->scanFinished(); break;
        case 9: _t->createCtl((*reinterpret_cast< QBluetoothDeviceInfo(*)>(_a[1]))); break;
        case 10: _t->serviceDiscovered((*reinterpret_cast< const QBluetoothUuid(*)>(_a[1]))); break;
        case 11: _t->serviceScanDone(); break;
        case 12: _t->serviceStateChanged((*reinterpret_cast< QLowEnergyService::ServiceState(*)>(_a[1]))); break;
        case 13: _t->searchCharacteristic(); break;
        case 14: _t->BleServiceCharacteristicChanged((*reinterpret_cast< const QLowEnergyCharacteristic(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 15: _t->BleServiceCharacteristicRead((*reinterpret_cast< const QLowEnergyCharacteristic(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 16: _t->BleServiceCharacteristicWrite((*reinterpret_cast< const QLowEnergyCharacteristic(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 17: _t->sendBleMsg((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QBluetoothDeviceInfo >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QBluetoothDeviceInfo >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QBluetoothDeviceInfo >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QBluetoothUuid >(); break;
            }
            break;
        case 12:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QLowEnergyService::ServiceState >(); break;
            }
            break;
        case 14:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QLowEnergyCharacteristic >(); break;
            }
            break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QLowEnergyCharacteristic >(); break;
            }
            break;
        case 16:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QLowEnergyCharacteristic >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (BLEConnect::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&BLEConnect::fromBle)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (BLEConnect::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&BLEConnect::receiveBleMsg)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (BLEConnect::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&BLEConnect::sendRquest)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (BLEConnect::*)(QBluetoothDeviceInfo );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&BLEConnect::returnAddress)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (BLEConnect::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&BLEConnect::addItems)) {
                *result = 4;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject BLEConnect::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_BLEConnect.data,
    qt_meta_data_BLEConnect,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *BLEConnect::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BLEConnect::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_BLEConnect.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int BLEConnect::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void BLEConnect::fromBle(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void BLEConnect::receiveBleMsg(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void BLEConnect::sendRquest(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void BLEConnect::returnAddress(QBluetoothDeviceInfo _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void BLEConnect::addItems(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
