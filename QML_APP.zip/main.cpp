#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "bleconnect.h"
#include <QTimer>

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);

    // 欢迎界面延时2s显示
    QTimer::singleShot(1500,NULL,[=](){
        QtAndroid::hideSplashScreen();
    });

    qmlRegisterType<BLEConnect>("BleConnect.module",1,0,"BLE");

    QQmlApplicationEngine engine;

    engine.setOfflineStoragePath("./");  //设置数据库存储路径

    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
